import ApiErrors from "./ApiErrors";

export default [...ApiErrors];
