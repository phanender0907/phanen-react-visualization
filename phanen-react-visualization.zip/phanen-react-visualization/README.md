## Create React App Visualization

Go to the directory in your terminal<br/>
Run npm install <br/>
Run npm start<br/>
go to "http://localhost:3000/" enjoy =)
<br/>
Tool used: React v16.8, Recharts, React Hook, react-redux, subscriptions-transport-ws, urql, material UI, semantic UI,